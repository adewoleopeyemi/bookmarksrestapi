from os import access
from flask  import Blueprint, request, jsonify
from sqlalchemy import Identity
from werkzeug.security import check_password_hash, generate_password_hash
from src.constants.http_status_codes import HTTP_200_OK, HTTP_201_CREATED, HTTP_400_BAD_REQUEST, HTTP_401_UNAUTHORIZED, HTTP_409_CONFLICT
import validators
from src.database import db, User
from flask_jwt_extended import jwt_required, create_access_token, create_refresh_token, get_jwt_identity


auth = Blueprint("auth", __name__, url_prefix="/api/v1/auth")

@auth.post("/register")
def register():
    username = request.json.get("username","")
    email = request.json.get("email","")
    password = request.json.get("password","")
    
    if len(password) < 8:
        return jsonify({"response_code": HTTP_400_BAD_REQUEST,
        "response_message":"Password is too short"})

    if len(username) < 3:
        return jsonify({"response_code": HTTP_400_BAD_REQUEST,
        "response_body":"Username is too short"})

    if not username.isalnum() or " " in username:
        return jsonify({"response_code": HTTP_400_BAD_REQUEST,
        "response_body":"Username should be alpha"})

    if not validators.email(email):
        return jsonify({"response_code": HTTP_400_BAD_REQUEST,
        "response_body":"Email is not valid"})

    if User.query.filter_by(email=email).first() is not None:
        return jsonify({"response_code": HTTP_409_CONFLICT,
        "response_body":"Email is already taken"})

    if User.query.filter_by(username=username).first() is not None:
        return jsonify({"response_code": HTTP_409_CONFLICT,
        "response_body":"Username is already taken"})

    pwd_hash = generate_password_hash(password)
    user = User(email=email, username=username, password=pwd_hash)
    db.session.add(user)
    db.session.commit()

    return jsonify({"response_code": HTTP_201_CREATED, 
    "response_body":{
        "username": username,
        "email": email, 
        "access_token": create_access_token(user.id),
        "refresh_token": create_refresh_token(user.id)
    }})

@auth.post("/login")
def login():
    email = request.json.get("email","")
    password = request.json.get("password","")

    user = User.query.filter_by(email=email).first()

    if user:
        is_password_correct = check_password_hash(user.password, password)

        if is_password_correct:
            refresh_token = create_refresh_token(identity=user.id)
            access_token = create_access_token(identity=user.id)
            return jsonify({"response_code": HTTP_200_OK, 
            "response_body":{
                "username": user.username,
                "email": user.email,
                "access_token": access_token, 
                "refresh_token": refresh_token
            }})
        else:
            return jsonify({"response_code": HTTP_401_UNAUTHORIZED,
                "response_body":"Wrong Email or Password"
                })
    
    return jsonify({"response_code": HTTP_401_UNAUTHORIZED,
                "response_body":"Wrong Email or Password"
                })
    


@auth.post("/me")
@jwt_required()
def me():
    user_id = get_jwt_identity()
    user = User.query.filter_by(id=user_id).first()
    return {
        "email": user.email, 
        "username": user.username
    }

@auth.get("/token/refresh")
@jwt_required(refresh=True)
def refresh():
    Identity = get_jwt_identity()
    access_token = create_access_token(identity=Identity)
    return jsonify({"response_code": HTTP_200_OK,
                "response_body": access_token
            })