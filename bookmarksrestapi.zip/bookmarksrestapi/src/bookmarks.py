from crypt import methods
from flask  import Blueprint, jsonify, request
import validators

from src.constants.http_status_codes import HTTP_200_OK, HTTP_400_BAD_REQUEST, HTTP_404_NOT_FOUND
from src.database import Bookmark, db

from flask_jwt_extended import get_jwt_identity, jwt_required


bookmark = Blueprint("bookmarks", __name__, url_prefix="/api/v1/bookmarks")

@bookmark.route("/", methods=["POST", "GET"])
@jwt_required()
def get_all():
    current_user = get_jwt_identity()
    if request.method == "POST":
        body = request.get_json().get("body", "")
        url = request.get_json().get("url", "")
        if validators.url(url):
            return jsonify({
                "response_code": 400, 
                "response_body": "Invalid url"
            }), HTTP_400_BAD_REQUEST
        if Bookmark.query.filter_by(user_id=current_user).filter_by(url=url).first():
            return jsonify({
                "response_code": 400, 
                "response_body": "URL already exists"
            })
        bookmark = Bookmark(body=body, url=url, user_id=current_user)
        db.session.add(bookmark)
        db.session.commit()
        return jsonify({"response_code":200,
        "response_body": {
            "id":bookmark.id,
            "url": bookmark.url,
            "short_url": bookmark.short_url,
            "visits": bookmark.visits,
            "body": bookmark.body, 
            "updated_at": bookmark.updated_at, 
            "created_at": bookmark.created_at            
        }})  

    else:
        page = request.args("page", 1, type=int)
        per_page = request.args("per_page", 5, type=int)
        bookmarks = Bookmark.query.filter_by(user_id=current_user).paginate(page=page, per_page=per_page)
        data = []
        for item in bookmarks.items:
            data.append({
            "id":item.id,
            "url": item.url,
            "short_url": item.short_url,
            "visits": item.visits,
            "body": item.body, 
            "updated_at": item.updated_at, 
            "created_at": item.created_at
            })
        meta = {
            "page", bookmarks.page, 
            "pages", bookmarks.pages,
            "total_count", bookmarks.total
        }
        return jsonify({
            "response_code": 200, 
            "response_body": {
                "data": data,
                "meta": meta}
        })


@bookmark.get("/<int:id>")
@jwt_required()
def get_bookmark(id):
    current_user = get_jwt_identity()
    if Bookmark.query.filter_by(user_id = current_user, id=id).first():
        item = Bookmark.query.filter_by(user_id = current_user, id=id).first()
        return jsonify({"response_code": HTTP_200_OK,
        "response_message":{
            "id":item.id,
            "url": item.url,
            "short_url": item.short_url,
            "visits": item.visits,
            "body": item.body, 
            "updated_at": item.updated_at, 
            "created_at": item.created_at
        }})
    else:
        return jsonify({
            "response_code": HTTP_404_NOT_FOUND, 
            "response_message": "Bookmark not found"
        }) 

@bookmark.put("/<int:id>")
@bookmark.patch("/<int:id>")
@jwt_required()
def edit_bookmark(id):
    current_user = get_jwt_identity()
    bookmark = Bookmark.query.filter_by(user_id = current_user, id=id).first()
    if not bookmark:
        return jsonify({
            "response_code": HTTP_404_NOT_FOUND, 
            "response_message": "Bookmark not found"
        }) 
    body = request.get_json().get("body", "")
    url = request.get_json().get("url", "")
    if validators.url(url):
        return jsonify({
                "response_code": HTTP_400_BAD_REQUEST, 
                "response_body": "Invalid url"
            }), HTTP_400_BAD_REQUEST
    bookmark.url = url
    bookmark.body = body
    db.session.commit()
    return jsonify({"response_code": HTTP_200_OK,
        "response_message":{
            "id":bookmark.id,
            "url": bookmark.url,
            "short_url": bookmark.short_url,
            "visits": bookmark.visits,
            "body": bookmark.body, 
            "updated_at": bookmark.updated_at, 
            "created_at": bookmark.created_at
        }})




@bookmark.delete("/<int:id>")
@jwt_required()
def delete_bookmark(id):
    current_user = get_jwt_identity()
    bookmark = Bookmark.query.filter_by(user_id = current_user, id=id).first()
    if not bookmark:
        return jsonify({
            "response_code": HTTP_404_NOT_FOUND, 
            "response_message": "Bookmark not found"
        }) 
    db.session.delete(bookmark)
    db.session.commit()
    return jsonify({"response_code": HTTP_200_OK,
        "response_message":{
            "id":bookmark.id,
            "url": bookmark.url,
            "short_url": bookmark.short_url,
            "visits": bookmark.visits,
            "body": bookmark.body, 
            "updated_at": bookmark.updated_at, 
            "created_at": bookmark.created_at
        }})


@bookmark.get("/me")
def me():
    return {"user":"me"}
