from flask import Flask, jsonify, redirect
import os
from src.auth import auth
from src.bookmarks import bookmark
from src.constants.http_status_codes import HTTP_404_NOT_FOUND
from src.database import Bookmark, db
from flask_jwt_extended import JWTManager, jwt_required, get_jwt_identity

def create_app(test_config=None):
    app = Flask(__name__,
    instance_relative_config=True)

    if test_config is None:
        app.config.from_mapping(
            SECRET_KEY=os.environ.get("SECRET_KEY"),
            SQLALCHEMY_DATABASE_URI=os.environ.get("SQLALCHEMY_DB_URI"), 
            SQLALCHEMY_TRACK_MODIFICATIONS=False,
            JWT_SECRET_KEY=os.environ.get("JWT_SECRET_KEY")
        )
    else:
        app.config.from_mapping(test_config)
    
    db.app = app
    db.init_app(app)

    JWTManager(app)

    app.register_blueprint(auth)
    app.register_blueprint(bookmark)

    @app.get('/<short_url>')
    @jwt_required()
    def redirect_to_url(short_url):
        current_user = get_jwt_identity()
        bookmark = Bookmark.query.filter_by(user_id=current_user, short_url=short_url).first_or_404()
        if bookmark:
            bookmark.visits +=1
            db.session.commit()
            return redirect(bookmark.url)

    @app.errorhandler(HTTP_404_NOT_FOUND)
    def handle_404(e):
        return jsonify({
            "response_code": HTTP_404_NOT_FOUND, 
            "response_message": "Endpoint name not found"
        })


    return app

if __name__ == "__main__":
    create_app(None).run("0.0.0.0", port=5000)

